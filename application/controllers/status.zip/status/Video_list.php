<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Video_list extends CI_Controller 
{
    public function __construct()
    {
        parent::__construct();
        $this->base_url = BASE_URL_2XSTATUS.'video_list';
    }
    
    public function index()
    {
        $this->load->view(STATUS_VIEW.'video_list');
    }

    public function list_video($page)
    {
        $pagination = '';

        $limit = 10;
        $start = ($page - 1) * $limit;

        $total = $this->crud->countrow('post_video');
        $page_limit = $total/$limit;

        if ($page_limit > 0) {
                $page_limit = $total/1;
        }

        if($page <= $page_limit)
        {

            $this->db->limit($limit, $start);
            $result = $this->crud->get_with_join('post_video v',
            'v.id as id,
            v.name as name,
            v.image_thumbnail as image_thumbnail,
            v.video_link as video_link,
            v.video_view as video_view,
            v.upload_type as upload_type,
            v.status as status,
            cat.name as category_name
            ', 
            ["v.status"=>1,'v.video_type'=>1],['category cat' => 'v.category_id = cat.id'], ['left'],'v.id','DESC');

            $post_video = '';

            if (!empty($result)) 
            {
                foreach ($result as $key => $value) 
                {
                    $img_path = '';
                    $video_path = '';
                    if ($value->upload_type == 'upload') 
                    {
                        $img_path = BASE_URL.IMAGE_THUMBNAIL.$value->image_thumbnail;
                        $video_path = BASE_URL.VIDEO_THUMBNAIL.$value->video_link;
                    }else{
                        $img_path = $value->image_thumbnail;
                        $video_path = $value->video_link;
                    }

                    $post_video .= '<div class="col-md-3">
                        <div class="white_card position-relative mb_20 ">
                            <div class="card-body">';

                    $post_video .= '<img src="'.$img_path.'" alt="" class="" style="width: 100%;height: 350px;border-radius: 5px;" >';

                    $post_video .= '<div class="row my-4">';
                    $post_video .= '<div class="col">
                    <span class="badge_btn_1  mb-1">'.$value->id.'</span>
                    <span class="badge_btn_3  mb-1">'.$value->category_name.'</span>  <a href="#" class="f_w_400 color_text_3 f_s_14 d-block">'.$value->name.'</a></div>';
                    $post_video .= '</div>';


                    $status = 'badge_active3';
                    if ($value->status == '1') {
                        $status = 'badge_active';
                    }
                    
                    $post_video .= '<div class="action_btns d-flex">
                                                            <a href="#" class="'.$status.' mr_10">Active</a>
                                                            <a href="#" class="action_btn mr_10"> <i class="far fa-edit"></i> </a>

                                                            <a href="#" class="action_btn"> <i class="fas fa-trash"></i> </a>
                                                        </div>';

                    $post_video .= '</div>
                        </div>
                    </div>';
                }
            }


            $current_page = $page;


            $pagination .= '<nav style="padding: 20px;">
                            <ul class="pagination">';

                            $page_limit = $page_limit;
                            if($current_page > 1) 
                            {

                            $pagination .= '<li class="page-item"><a href="javascript:void(0)" class="page-link pagination-button" data-page="'.($current_page - 1).'">Previous<a/></li>';
                            }

                            if(($current_page - 1) > 1) {
                                $pagination .= '<li class="page-item"><a class="page-link">...<a/></li>';
                             }

                             for ($i=($current_page - 1); $i <= ($current_page +1) ; $i++) {

                                if($i == $current_page) {
                                    $current = 'active';
                                } else {
                                    $current = '';
                                }

                                if($i >= 1 && $i <= $page_limit) {

                                $pagination .= '<li class="page-item '.$current.' pagination-button" data-page="'.$i.'"><a href="javascript:void(0)" class="page-link">'.$i.'<a/></li>';

                                // $pagination .= '<li class="'.$current.'><a href="javascript:void(0)" class="pagination-button" data-page="'.$i.'">'.$i.'</a></li>';

                                 }
                              }

                              if(($current_page + 1) < $page_limit) 
                              {

                                     $pagination .= '<li class="page-item"><a class="page-link">...<a/></li>';
                               }
                           if($current_page < $page_limit){

                             $pagination .= '<li class="page-item"><a href="javascript:void(0)" class="page-link pagination-button" data-page="'.($current_page + 1).'">Next<a/></li>';
                           }

            $pagination .= '</ul>';

            $pagination .= '<p class="justify-content-end">Showing '.($start + 1).'–'.($start + $limit).' of '.$total.' results</p>';

            $pagination .= '</nav>';


            echo json_encode([
                                'response' => true,
                                'pagination' => $pagination,
                                'post_video' => $post_video,
                            ]);
        }


        

    }
}
