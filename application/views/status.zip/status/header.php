<!DOCTYPE html>
<html lang="zxx">
<meta http-equiv="content-type" content="text/html;charset=UTF-8" />
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <title>2x Status</title>

    <link rel="icon" href="<?=STATUS_ASSETS?>img/mini_logo.png" type="image/png">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="<?=STATUS_ASSETS?>css/bootstrap.min.css" />
    <!-- themefy CSS -->
    <link rel="stylesheet" href="<?=STATUS_ASSETS?>vendors/themefy_icon/themify-icons.css" />
    <!-- select2 CSS -->
    <link rel="stylesheet" href="<?=STATUS_ASSETS?>vendors/niceselect/css/nice-select.css" />
    <!-- owl carousel CSS -->
    <link rel="stylesheet" href="<?=STATUS_ASSETS?>vendors/owl_carousel/css/owl.carousel.css" />
    <!-- gijgo css -->
    <link rel="stylesheet" href="<?=STATUS_ASSETS?>vendors/gijgo/gijgo.min.css" />
    <!-- font awesome CSS -->
    <link rel="stylesheet" href="<?=STATUS_ASSETS?>vendors/font_awesome/css/all.min.css" />
    <link rel="stylesheet" href="<?=STATUS_ASSETS?>vendors/tagsinput/tagsinput.css" />

    <!-- date picker -->
     <link rel="stylesheet" href="<?=STATUS_ASSETS?>vendors/datepicker/date-picker.css" />

     <link rel="stylesheet" href="<?=STATUS_ASSETS?>vendors/vectormap-home/vectormap-2.0.2.css" />
     
     <!-- scrollabe  -->
     <link rel="stylesheet" href="<?=STATUS_ASSETS?>vendors/scroll/scrollable.css" />
    <!-- datatable CSS -->
    <link rel="stylesheet" href="<?=STATUS_ASSETS?>vendors/datatable/css/jquery.dataTables.min.css" />
    <link rel="stylesheet" href="<?=STATUS_ASSETS?>vendors/datatable/css/responsive.dataTables.min.css" />
    <link rel="stylesheet" href="<?=STATUS_ASSETS?>vendors/datatable/css/buttons.dataTables.min.css" />
    <!-- text editor css -->
    <link rel="stylesheet" href="<?=STATUS_ASSETS?>vendors/text_editor/summernote-bs4.css" />
    <!-- morris css -->
    <link rel="stylesheet" href="<?=STATUS_ASSETS?>vendors/morris/morris.css">
    <!-- metarial icon css -->
    <link rel="stylesheet" href="<?=STATUS_ASSETS?>vendors/material_icon/material-icons.css" />

    <!-- menu css  -->
    <link rel="stylesheet" href="<?=STATUS_ASSETS?>css/metisMenu.css">
    <!-- style CSS -->
    <link rel="stylesheet" href="<?=STATUS_ASSETS?>css/style.css" />
    <link rel="stylesheet" href="<?=STATUS_ASSETS?>css/colors/default.css" id="colorSkinCSS">


<style type="text/css">
    
    #sidebar_menu .active .nav_title span{
        color:#F65365 !important;
    }

</style>

</head>
<body class="crm_body_bg">

    <?php $this->load->view(STATUS_VIEW.'sidebar'); ?>

    <section class="main_content dashboard_part large_header_bg">