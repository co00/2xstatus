<?php $this->load->view(STATUS_VIEW.'header'); ?>

<div class="container-fluid no-gutters">
        <div class="row">
            <div class="col-lg-12 p-0 ">
                <div class="header_iner d-flex justify-content-between align-items-center">
                    <div class="sidebar_icon d-lg-none">
                        <i class="ti-menu"></i>
                    </div>
                    <label class="switch_toggle d-none d-lg-block" for="checkbox">
                        <input type="checkbox" id="checkbox">
                        <div class="slider round open_miniSide"></div>
                    </label>

                    <div class="header_right d-flex justify-content-between align-items-center">
                        <div class="header_notification_warp d-flex align-items-center">
                            <li>
                                <div class="serach_button">
                                    <i class="ti-search"></i>
                                    <div class="serach_field-area d-flex align-items-center">
                                        <div class="search_inner">
                                            <form action="#">
                                                <div class="search_field">
                                                    <input type="text" placeholder="Search here..." >
                                                </div>
                                                <button class="close_search"> <i class="ti-search"></i> </button>
                                            </form>
                                        </div>
                                        <span class="f_s_14 f_w_400 ml_25 white_text text_white" >Apps</span>
                                    </div>
                                </div>
                            </li>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>


<div class="main_content_iner overly_inner ">
        <div class="container-fluid p-0 ">
            <!-- page title  -->
            <div class="row">
                <div class="col-12">
                    <div class="page_title_box d-flex flex-wrap align-items-center justify-content-between">
                        <div class="page_title_left">
                            <h3 class="f_s_25 f_w_700 dark_text" >Video List</h3>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-xl-12 ">
                    <div class="white_card mb_30 card_height_100">

                        <div class="pagination_body">
                            
                        </div>
                    </div>


                </div>
            </div>

            

            <div class="row video_list_body"></div>

        </div>
    </div>
<?php $this->load->view(STATUS_VIEW.'footer'); ?>

<script type="text/javascript">
	

$(document).ready(function(){



$(document).off('click','.pagination-button').on('click','.pagination-button',function(e){
e.preventDefault();

var page = $(this).data('page');

list_video(page);

});


list_video(1);

function list_video(page)
{

    $.ajax({
                url: '<?=BASE_URL_2XSTATUS?>Video_list/list_video/'+page,
                type:'GET',
                dataType: 'JSON',
                success: function(response) {
                    if(response.response ) {
                        
                        $('.pagination_body').html(response.pagination);
                        $('.video_list_body').html(response.post_video);
                    }
                },
                error: function(repsonse){
                }
            });
} 


});  

</script>