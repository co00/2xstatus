<!-- footer part -->
<div class="footer_part">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-12">
                <div class="footer_iner text-center">
                    <p>2020 © Influence - Designed by <a href="#"> <i class="ti-heart"></i> </a><a href="#"> DashboardPack</a></p>
                </div>
            </div>
        </div>
    </div>
</div>
</section>
<!-- main content part end -->

<!-- ### CHAT_MESSAGE_BOX   ### -->

<!--/### CHAT_MESSAGE_BOX  ### -->

<div id="back-top" style="display: none;">
    <a title="Go to Top" href="#">
        <i class="ti-angle-up"></i>
    </a>
</div>

<!-- footer  -->
<script src="<?=STATUS_ASSETS?>js/jquery-3.4.1.min.js"></script>
<!-- popper js -->
<script src="<?=STATUS_ASSETS?>js/popper.min.js"></script>
<!-- bootstarp js -->
<script src="<?=STATUS_ASSETS?>js/bootstrap.min.js"></script>
<!-- sidebar menu  -->
<script src="<?=STATUS_ASSETS?>js/metisMenu.js"></script>
<!-- waypoints js -->
<script src="<?=STATUS_ASSETS?>vendors/count_up/jquery.waypoints.min.js"></script>
<!-- waypoints js -->
<script src="<?=STATUS_ASSETS?>vendors/chartlist/Chart.min.js"></script>
<!-- counterup js -->
<script src="<?=STATUS_ASSETS?>vendors/count_up/jquery.counterup.min.js"></script>

<!-- nice select -->
<script src="<?=STATUS_ASSETS?>vendors/niceselect/js/jquery.nice-select.min.js"></script>
<!-- owl carousel -->
<script src="<?=STATUS_ASSETS?>vendors/owl_carousel/js/owl.carousel.min.js"></script>

<!-- responsive table -->
<script src="<?=STATUS_ASSETS?>vendors/datatable/js/jquery.dataTables.min.js"></script>
<script src="<?=STATUS_ASSETS?>vendors/datatable/js/dataTables.responsive.min.js"></script>
<script src="<?=STATUS_ASSETS?>vendors/datatable/js/dataTables.buttons.min.js"></script>
<script src="<?=STATUS_ASSETS?>vendors/datatable/js/buttons.flash.min.js"></script>
<script src="<?=STATUS_ASSETS?>vendors/datatable/js/jszip.min.js"></script>
<script src="<?=STATUS_ASSETS?>vendors/datatable/js/pdfmake.min.js"></script>
<script src="<?=STATUS_ASSETS?>vendors/datatable/js/vfs_fonts.js"></script>
<script src="<?=STATUS_ASSETS?>vendors/datatable/js/buttons.html5.min.js"></script>
<script src="<?=STATUS_ASSETS?>vendors/datatable/js/buttons.print.min.js"></script>

<!-- datepicker  -->
<script src="<?=STATUS_ASSETS?>vendors/datepicker/datepicker.js"></script>
<script src="<?=STATUS_ASSETS?>vendors/datepicker/datepicker.en.js"></script>
<script src="<?=STATUS_ASSETS?>vendors/datepicker/datepicker.custom.js"></script>

<script src="<?=STATUS_ASSETS?>js/chart.min.js"></script>
<script src="<?=STATUS_ASSETS?>vendors/chartjs/roundedBar.min.js"></script>

<!-- progressbar js -->
<script src="<?=STATUS_ASSETS?>vendors/progressbar/jquery.barfiller.js"></script>
<!-- tag input -->
<script src="<?=STATUS_ASSETS?>vendors/tagsinput/tagsinput.js"></script>
<!-- text editor js -->
<script src="<?=STATUS_ASSETS?>vendors/text_editor/summernote-bs4.js"></script>
<script src="<?=STATUS_ASSETS?>vendors/am_chart/amcharts.js"></script>

<!-- scrollabe  -->
<script src="<?=STATUS_ASSETS?>vendors/scroll/perfect-scrollbar.min.js"></script>
<script src="<?=STATUS_ASSETS?>vendors/scroll/scrollable-custom.js"></script>

<!-- vector map  -->
<script src="<?=STATUS_ASSETS?>vendors/vectormap-home/vectormap-2.0.2.min.js"></script>
<script src="<?=STATUS_ASSETS?>vendors/vectormap-home/vectormap-world-mill-en.js"></script>

<!-- apex chrat  -->
<script src="<?=STATUS_ASSETS?>vendors/apex_chart/apex-chart2.js"></script>
<script src="<?=STATUS_ASSETS?>vendors/apex_chart/apex_dashboard.js"></script>

<script src="<?=STATUS_ASSETS?>vendors/echart/echarts.min.js"></script>


<script src="<?=STATUS_ASSETS?>vendors/chart_am/core.js"></script>
<script src="<?=STATUS_ASSETS?>vendors/chart_am/charts.js"></script>
<script src="<?=STATUS_ASSETS?>vendors/chart_am/animated.js"></script>
<script src="<?=STATUS_ASSETS?>vendors/chart_am/kelly.js"></script>
<script src="<?=STATUS_ASSETS?>vendors/chart_am/chart-custom.js"></script>
<!-- custom js -->
<script src="<?=STATUS_ASSETS?>js/dashboard_init.js"></script>
<script src="<?=STATUS_ASSETS?>js/custom.js"></script>
</body>
</html>
